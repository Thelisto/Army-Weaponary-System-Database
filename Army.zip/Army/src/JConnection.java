/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;
/**
 *
 * @author Datta
 */
public class JConnection {
    public static Connection ConnerDb(){
    try{
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/project", "root", "");
        System.out.println("Connected");
        return conn;
        

    }catch(Exception e)
    {
    JOptionPane.showMessageDialog(null, e);
    return null;
    }
    }



}
